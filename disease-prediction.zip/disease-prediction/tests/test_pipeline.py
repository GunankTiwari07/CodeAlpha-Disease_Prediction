"""
tests/test_pipeline.py
-----------------------
Unit tests for data loading, preprocessing, and model pipeline.
"""

import os
import sys
import pytest
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from data_loader import download_breast_cancer, load_dataset
from feature_engineering import preprocess, get_preprocessing_pipeline, feature_importance_summary


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def breast_cancer_data():
    """Download and return breast cancer data once for all tests."""
    download_breast_cancer()
    return load_dataset("breast_cancer")


# ── Data Loader Tests ─────────────────────────────────────────────────────────

class TestDataLoader:
    def test_breast_cancer_shape(self, breast_cancer_data):
        X, y = breast_cancer_data
        assert X.shape[0] > 0, "Dataset should have rows"
        assert X.shape[1] > 0, "Dataset should have features"

    def test_breast_cancer_target_binary(self, breast_cancer_data):
        _, y = breast_cancer_data
        unique_vals = set(y.unique())
        assert unique_vals.issubset({0, 1}), "Target must be binary (0 or 1)"

    def test_breast_cancer_no_all_null_columns(self, breast_cancer_data):
        X, _ = breast_cancer_data
        assert not (X.isnull().all(axis=0).any()), "No column should be entirely null"


# ── Preprocessing Tests ───────────────────────────────────────────────────────

class TestPreprocessing:
    def test_train_test_split_sizes(self, breast_cancer_data):
        X, y = breast_cancer_data
        X_train, X_test, y_train, y_test, _ = preprocess(X, y, "breast_cancer")
        total = len(X_train) + len(X_test)
        assert abs(total - len(y)) <= 1  # allow ±1 for rounding

    def test_no_nan_after_imputation(self, breast_cancer_data):
        X, y = breast_cancer_data
        X_train, X_test, y_train, y_test, _ = preprocess(X, y, "breast_cancer")
        assert not np.isnan(X_train).any(), "No NaN should remain in training set"
        assert not np.isnan(X_test).any(), "No NaN should remain in test set"

    def test_pipeline_returns_array(self, breast_cancer_data):
        X, y = breast_cancer_data
        X_train, X_test, y_train, y_test, pipeline = preprocess(X, y, "breast_cancer")
        assert isinstance(X_train, np.ndarray)
        assert isinstance(X_test, np.ndarray)

    def test_scaled_mean_near_zero(self, breast_cancer_data):
        X, y = breast_cancer_data
        X_train, _, _, _, _ = preprocess(X, y, "breast_cancer")
        col_means = np.abs(X_train.mean(axis=0))
        assert col_means.max() < 0.5, "StandardScaler should centre features near 0"


# ── Model Training Tests ──────────────────────────────────────────────────────

class TestModelTraining:
    def test_logistic_regression_trains(self, breast_cancer_data):
        X, y = breast_cancer_data
        X_train, X_test, y_train, y_test, _ = preprocess(X, y, "breast_cancer")
        model = LogisticRegression(max_iter=1000, random_state=42)
        model.fit(X_train, y_train)
        score = model.score(X_test, y_test)
        assert score > 0.80, f"LR accuracy too low: {score:.4f}"

    def test_predictions_are_binary(self, breast_cancer_data):
        X, y = breast_cancer_data
        X_train, X_test, y_train, y_test, _ = preprocess(X, y, "breast_cancer")
        model = LogisticRegression(max_iter=1000, random_state=42)
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        assert set(preds).issubset({0, 1}), "Predictions must be 0 or 1"


# ── Feature Importance Tests ──────────────────────────────────────────────────

class TestFeatureImportance:
    def test_importance_returns_dataframe(self, breast_cancer_data):
        from sklearn.ensemble import RandomForestClassifier
        X, y = breast_cancer_data
        X_train, _, y_train, _, _ = preprocess(X, y, "breast_cancer")
        rf = RandomForestClassifier(n_estimators=50, random_state=42)
        rf.fit(X_train, y_train)
        df = feature_importance_summary(rf, [f"f{i}" for i in range(X_train.shape[1])])
        assert isinstance(df, pd.DataFrame)
        assert len(df) <= 10

    def test_importance_sorted_descending(self, breast_cancer_data):
        from sklearn.ensemble import RandomForestClassifier
        X, y = breast_cancer_data
        X_train, _, y_train, _, _ = preprocess(X, y, "breast_cancer")
        rf = RandomForestClassifier(n_estimators=50, random_state=42)
        rf.fit(X_train, y_train)
        df = feature_importance_summary(rf, [f"f{i}" for i in range(X_train.shape[1])])
        if len(df) > 1:
            assert df["importance"].iloc[0] >= df["importance"].iloc[1]
