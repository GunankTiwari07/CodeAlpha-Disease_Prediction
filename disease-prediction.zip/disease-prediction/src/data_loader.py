"""
data_loader.py
--------------
Handles downloading and loading of UCI medical datasets.
"""

import argparse
import os
import pandas as pd
import numpy as np
import yaml
from sklearn.datasets import load_breast_cancer

# ── Config ────────────────────────────────────────────────────────────────────
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config.yaml")

with open(CONFIG_PATH, "r") as f:
    CONFIG = yaml.safe_load(f)

RAW_DIR = CONFIG["paths"]["data_raw"]
os.makedirs(RAW_DIR, exist_ok=True)


# ── Download helpers ───────────────────────────────────────────────────────────

def download_heart_disease():
    """Download Cleveland Heart Disease dataset."""
    url = (
        "https://archive.ics.uci.edu/ml/machine-learning-databases/"
        "heart-disease/processed.cleveland.data"
    )
    columns = [
        "age", "sex", "cp", "trestbps", "chol", "fbs",
        "restecg", "thalach", "exang", "oldpeak", "slope",
        "ca", "thal", "target",
    ]
    df = pd.read_csv(url, header=None, names=columns, na_values="?")
    df["target"] = (df["target"] > 0).astype(int)  # binary: 0=no disease, 1=disease
    df.to_csv(os.path.join(RAW_DIR, "heart.csv"), index=False)
    print(f"[✓] Heart Disease dataset saved  ({len(df)} rows)")
    return df


def download_diabetes():
    """Download Pima Indians Diabetes dataset."""
    url = (
        "https://raw.githubusercontent.com/jbrownlee/Datasets/master/"
        "pima-indians-diabetes.data.csv"
    )
    columns = [
        "Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
        "Insulin", "BMI", "DiabetesPedigreeFunction", "Age", "Outcome",
    ]
    df = pd.read_csv(url, header=None, names=columns)
    df.to_csv(os.path.join(RAW_DIR, "diabetes.csv"), index=False)
    print(f"[✓] Diabetes dataset saved  ({len(df)} rows)")
    return df


def download_breast_cancer():
    """Load Breast Cancer Wisconsin dataset from sklearn and save as CSV."""
    bc = load_breast_cancer(as_frame=True)
    df = bc.frame.copy()
    df.rename(columns={"target": "diagnosis"}, inplace=True)
    # 1 = malignant, 0 = benign  (sklearn encodes 0=malignant; flip for clarity)
    df["diagnosis"] = 1 - df["diagnosis"]
    df.to_csv(os.path.join(RAW_DIR, "breast_cancer.csv"), index=False)
    print(f"[✓] Breast Cancer dataset saved  ({len(df)} rows)")
    return df


def download_all():
    download_heart_disease()
    download_diabetes()
    download_breast_cancer()


# ── Load & basic clean ─────────────────────────────────────────────────────────

def load_dataset(name: str) -> tuple[pd.DataFrame, pd.Series]:
    """
    Load a raw CSV dataset and return (X, y).

    Parameters
    ----------
    name : str
        One of 'heart', 'diabetes', 'breast_cancer'.

    Returns
    -------
    X : pd.DataFrame  — feature matrix
    y : pd.Series     — target vector
    """
    cfg = CONFIG["datasets"][name]
    path = os.path.join(RAW_DIR, cfg["filename"])

    if not os.path.exists(path):
        print(f"[!] '{path}' not found. Downloading...")
        {"heart": download_heart_disease,
         "diabetes": download_diabetes,
         "breast_cancer": download_breast_cancer}[name]()

    df = pd.read_csv(path)

    # Drop duplicates
    df.drop_duplicates(inplace=True)

    target_col = cfg["target"]
    y = df[target_col]
    X = df.drop(columns=[target_col])

    print(f"[✓] Loaded '{name}': {X.shape[0]} samples, {X.shape[1]} features")
    return X, y


def get_dataset_info(name: str):
    """Print summary statistics for a dataset."""
    X, y = load_dataset(name)
    print(f"\n--- {name.upper()} ---")
    print(f"Shape : {X.shape}")
    print(f"Target distribution:\n{y.value_counts()}")
    print(f"Missing values:\n{X.isnull().sum()[X.isnull().sum() > 0]}")
    print(X.describe())


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Disease Prediction — Data Loader")
    parser.add_argument(
        "--download",
        action="store_true",
        help="Download all datasets from UCI / GitHub mirrors",
    )
    parser.add_argument(
        "--info",
        choices=["heart", "diabetes", "breast_cancer", "all"],
        help="Print dataset info",
    )
    args = parser.parse_args()

    if args.download:
        download_all()

    if args.info:
        names = ["heart", "diabetes", "breast_cancer"] if args.info == "all" else [args.info]
        for n in names:
            get_dataset_info(n)
