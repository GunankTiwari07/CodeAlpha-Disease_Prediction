"""
feature_engineering.py
-----------------------
Preprocessing and feature engineering pipeline for medical datasets.
"""

import numpy as np
import pandas as pd
import yaml
import os
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config.yaml")
with open(CONFIG_PATH, "r") as f:
    CONFIG = yaml.safe_load(f)

PROCESSED_DIR = CONFIG["paths"]["data_processed"]
os.makedirs(PROCESSED_DIR, exist_ok=True)


def get_preprocessing_pipeline() -> Pipeline:
    """Return a sklearn Pipeline for numeric features."""
    strategy = CONFIG["preprocessing"]["handle_missing"]
    pipe = Pipeline([
        ("imputer", SimpleImputer(strategy=strategy)),
        ("scaler", StandardScaler()),
    ])
    return pipe


def preprocess(
    X: pd.DataFrame,
    y: pd.Series,
    dataset_name: str,
    fit: bool = True,
    pipeline: Pipeline = None,
) -> tuple:
    """
    Preprocess features and split into train / test sets.

    Parameters
    ----------
    X            : Feature DataFrame
    y            : Target Series
    dataset_name : 'heart' | 'diabetes' | 'breast_cancer'
    fit          : If True, fit the pipeline; otherwise transform only.
    pipeline     : Pre-fitted pipeline (used when fit=False).

    Returns
    -------
    X_train, X_test, y_train, y_test, pipeline
    """
    cfg = CONFIG["datasets"][dataset_name]

    # Encode target if string
    le = None
    if y.dtype == object:
        le = LabelEncoder()
        y = pd.Series(le.fit_transform(y), name=y.name)

    # Encode categorical columns (one-hot)
    cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()
    if cat_cols:
        X = pd.get_dummies(X, columns=cat_cols, drop_first=True)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=cfg["test_size"],
        random_state=cfg["random_state"],
        stratify=y,
    )

    # Scale
    if CONFIG["preprocessing"]["scale_features"]:
        if fit:
            pipeline = get_preprocessing_pipeline()
            X_train = pipeline.fit_transform(X_train)
        else:
            X_train = pipeline.transform(X_train)
        X_test = pipeline.transform(X_test)

    return X_train, X_test, y_train, y_test, pipeline


def feature_importance_summary(model, feature_names: list, top_n: int = 10) -> pd.DataFrame:
    """
    Extract feature importances from tree-based models.

    Works with Random Forest, XGBoost, etc.
    """
    if hasattr(model, "feature_importances_"):
        imp = model.feature_importances_
    elif hasattr(model, "coef_"):
        imp = np.abs(model.coef_[0])
    else:
        return pd.DataFrame()

    df = pd.DataFrame({"feature": feature_names, "importance": imp})
    df.sort_values("importance", ascending=False, inplace=True)
    return df.head(top_n).reset_index(drop=True)
