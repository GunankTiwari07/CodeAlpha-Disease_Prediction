"""
app.py
------
Streamlit demo app for Disease Prediction.

Run:
    streamlit run app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os
import json
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

# ── Page Config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Disease Prediction",
    page_icon="🏥",
    layout="wide",
)

st.title("🏥 Disease Prediction from Medical Data")
st.markdown(
    "Predict the likelihood of **Heart Disease**, **Diabetes**, or **Breast Cancer** "
    "using machine learning. Choose a dataset, fill in the patient details, and click Predict."
)

MODELS_DIR = "models"

DATASETS = {
    "Heart Disease": "heart",
    "Diabetes": "diabetes",
    "Breast Cancer": "breast_cancer",
}

MODEL_OPTIONS = {
    "Logistic Regression": "logistic_regression",
    "Support Vector Machine": "svm",
    "Random Forest": "random_forest",
    "XGBoost": "xgboost",
}

DISEASE_LABELS = {
    "heart": {0: ("🟢 No Heart Disease", "success"), 1: ("🔴 Heart Disease Detected", "error")},
    "diabetes": {0: ("🟢 No Diabetes", "success"), 1: ("🔴 Diabetes Detected", "error")},
    "breast_cancer": {0: ("🟢 Benign Tumour", "success"), 1: ("🔴 Malignant Tumour", "error")},
}

# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.header("⚙️ Settings")
    dataset_label = st.selectbox("Select Disease", list(DATASETS.keys()))
    model_label = st.selectbox("Select Model", list(MODEL_OPTIONS.keys()))
    dataset_name = DATASETS[dataset_label]
    model_name = MODEL_OPTIONS[model_label]

st.markdown(f"### 📋 {dataset_label} — Patient Input")

# ── Feature Input Forms ────────────────────────────────────────────────────────

def heart_inputs():
    c1, c2, c3 = st.columns(3)
    age = c1.slider("Age", 20, 80, 55)
    sex = c1.selectbox("Sex", [("Male", 1), ("Female", 0)], format_func=lambda x: x[0])[1]
    cp = c1.selectbox("Chest Pain Type", [(0, "Typical Angina"), (1, "Atypical Angina"),
                                           (2, "Non-anginal"), (3, "Asymptomatic")],
                      format_func=lambda x: x[1])[0]
    trestbps = c2.number_input("Resting BP (mm Hg)", 80, 200, 130)
    chol = c2.number_input("Cholesterol (mg/dl)", 100, 600, 240)
    fbs = c2.selectbox("Fasting Blood Sugar > 120", [("No", 0), ("Yes", 1)],
                       format_func=lambda x: x[0])[1]
    restecg = c3.selectbox("Resting ECG", [(0, "Normal"), (1, "ST-T Abnormality"),
                                            (2, "LV Hypertrophy")],
                           format_func=lambda x: x[1])[0]
    thalach = c3.slider("Max Heart Rate", 60, 220, 150)
    exang = c3.selectbox("Exercise Angina", [("No", 0), ("Yes", 1)],
                         format_func=lambda x: x[0])[1]
    oldpeak = st.slider("ST Depression (Oldpeak)", 0.0, 6.0, 1.0, 0.1)
    slope = st.selectbox("Slope of Peak ST", [(0, "Upsloping"), (1, "Flat"), (2, "Downsloping")],
                         format_func=lambda x: x[1])[0]
    ca = st.slider("No. of Major Vessels (0–3)", 0, 3, 0)
    thal = st.selectbox("Thalassemia", [(1, "Normal"), (2, "Fixed Defect"), (3, "Reversible Defect")],
                        format_func=lambda x: x[1])[0]
    return [age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]


def diabetes_inputs():
    c1, c2 = st.columns(2)
    pregnancies = c1.slider("Pregnancies", 0, 20, 2)
    glucose = c1.number_input("Glucose (mg/dL)", 0, 300, 120)
    bp = c1.number_input("Blood Pressure (mm Hg)", 0, 150, 70)
    skin = c1.number_input("Skin Thickness (mm)", 0, 100, 20)
    insulin = c2.number_input("Insulin (mu U/ml)", 0, 900, 80)
    bmi = c2.number_input("BMI", 0.0, 70.0, 32.0, 0.1)
    dpf = c2.number_input("Diabetes Pedigree Function", 0.0, 3.0, 0.5, 0.01)
    age = c2.slider("Age", 10, 90, 33)
    return [pregnancies, glucose, bp, skin, insulin, bmi, dpf, age]


def breast_cancer_inputs():
    st.info("Enter the mean values from cytology test results.")
    c1, c2, c3 = st.columns(3)
    radius_mean = c1.number_input("Radius Mean", 5.0, 30.0, 14.0, 0.1)
    texture_mean = c1.number_input("Texture Mean", 5.0, 40.0, 19.0, 0.1)
    perimeter_mean = c1.number_input("Perimeter Mean", 40.0, 200.0, 92.0, 0.1)
    area_mean = c2.number_input("Area Mean", 100.0, 2500.0, 655.0, 1.0)
    smoothness_mean = c2.number_input("Smoothness Mean", 0.05, 0.20, 0.096, 0.001)
    compactness_mean = c2.number_input("Compactness Mean", 0.0, 0.4, 0.104, 0.001)
    concavity_mean = c3.number_input("Concavity Mean", 0.0, 0.5, 0.089, 0.001)
    concave_points_mean = c3.number_input("Concave Points Mean", 0.0, 0.2, 0.049, 0.001)
    symmetry_mean = c3.number_input("Symmetry Mean", 0.1, 0.4, 0.18, 0.001)
    fractal_mean = c3.number_input("Fractal Dimension Mean", 0.04, 0.10, 0.063, 0.001)
    # Fill remaining 20 features with representative defaults
    defaults = [0.28, 1.1, 2.0, 20.0, 0.007, 0.025, 0.027, 0.01, 0.02, 0.004,
                17.0, 25.0, 115.0, 880.0, 0.132, 0.25, 0.27, 0.11, 0.29, 0.084]
    return [radius_mean, texture_mean, perimeter_mean, area_mean,
            smoothness_mean, compactness_mean, concavity_mean,
            concave_points_mean, symmetry_mean, fractal_mean] + defaults


# ── Render inputs ─────────────────────────────────────────────────────────────

if dataset_name == "heart":
    features = heart_inputs()
elif dataset_name == "diabetes":
    features = diabetes_inputs()
else:
    features = breast_cancer_inputs()

# ── Predict ───────────────────────────────────────────────────────────────────

st.markdown("---")
if st.button("🔍 Predict", type="primary", use_container_width=True):
    model_path = os.path.join(MODELS_DIR, f"{dataset_name}_{model_name}.pkl")
    pipeline_path = os.path.join(MODELS_DIR, f"{dataset_name}_pipeline.pkl")

    if not os.path.exists(model_path) or not os.path.exists(pipeline_path):
        st.error("⚠️ Models not found. Please run `python src/train.py --dataset all` first.")
    else:
        model = joblib.load(model_path)
        pipeline = joblib.load(pipeline_path)

        X = np.array(features).reshape(1, -1)
        X_scaled = pipeline.transform(X)

        prediction = int(model.predict(X_scaled)[0])
        probability = float(model.predict_proba(X_scaled)[0][prediction]) \
            if hasattr(model, "predict_proba") else None

        label, alert_type = DISEASE_LABELS[dataset_name][prediction]

        st.markdown("### 🎯 Prediction Result")
        if alert_type == "success":
            st.success(f"**{label}**" + (f"  —  Confidence: {probability*100:.1f}%" if probability else ""))
        else:
            st.error(f"**{label}**" + (f"  —  Confidence: {probability*100:.1f}%" if probability else ""))

        if probability:
            st.progress(probability)

        with st.expander("ℹ️ About this prediction"):
            st.markdown(f"""
- **Dataset:** {dataset_label}
- **Model:** {model_label}
- **Prediction:** {label}
- **Probability:** {f'{probability*100:.1f}%' if probability else 'N/A'}
            """)

# ── Footer ─────────────────────────────────────────────────────────────────────

st.markdown("---")
st.markdown(
    "<small>⚠️ This tool is for educational purposes only. "
    "Always consult a qualified healthcare professional.</small>",
    unsafe_allow_html=True,
)
